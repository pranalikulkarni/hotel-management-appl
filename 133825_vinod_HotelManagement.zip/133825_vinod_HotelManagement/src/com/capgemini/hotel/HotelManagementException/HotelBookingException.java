package com.capgemini.hotel.HotelManagementException;

public class HotelBookingException extends Exception
{
	public HotelBookingException(String msg)
	{
		super(msg);
	}
}
